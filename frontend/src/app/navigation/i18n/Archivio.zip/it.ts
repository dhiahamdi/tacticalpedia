export const locale = {
    lang: 'it',
    data: {
        'NAV': {
            'PROFILE': 'Profilo',
            'TRAINING': 'LIBRERIA TECNICA',
            'INSERT_TRAINING' : 'Nuova Proposta',
            'INSERT_DRAFT' : 'Nuova Bozza',
            'TRAINING_LIBRARY': 'Libreria Personale',
            'CUSTOMIZE_TRAINING': 'Personalizza Esperienza',
            'MANAGE_PROFILE': 'Grstisci Profilo',
            'MANAGE_SUBSCRIPTION': 'Gestisci Sottoscrizione',
            'CHANGE_PASSWORD': 'Cambia Password',
            'LOGOUT': 'Esci',
        }
    }
};